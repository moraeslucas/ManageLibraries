CREATE TABLE Cities (
CityID int IDENTITY(1,1) NOT NULL PRIMARY KEY,
CityName varchar(40) NOT NULL,
Region varchar(20) NOT NULL
)
GO