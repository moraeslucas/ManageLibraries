CREATE TABLE Libraries (
LibraryID int IDENTITY(1,1) NOT NULL PRIMARY KEY,
LibraryName varchar(40) NOT NULL,
Category varchar(20) NOT NULL,
City varchar(40) NOT NULL,
Symbol varchar(6)
)
GO