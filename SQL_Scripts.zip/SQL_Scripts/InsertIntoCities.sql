INSERT INTO Cities (CityName, Region)
       VALUES ('Auckland', 'Auckland'),
			  ('Christchurch', 'Canterbury'),
			  ('Dunedin', '	Otago'),
			  ('Hamilton', 'Waikato Region'),
	          ('Wellington', 'Wellington');
GO