﻿INSERT INTO Libraries (LibraryName, Category, City, Symbol)
       VALUES ('Canterbury Medical Library','Health','Christchurch','-'),
			  ('Environmental Protection Authority','Government','Wellington','WRMA'),
			  ('Holy Trinity Cathedral','Music Hire','Auckland','AHTC'),
			  ('New Zealand Law Society Library','Law','Dunedin','-'),
	          ('Te Wananga o Aotearoa','Tertiary','Hamilton','HTWA');
GO