﻿using System;
using System.Collections.Generic;

namespace ReactCrudLibrary.Models
{
    public partial class Cities
    {
        public int CityId { get; set; }
        public string CityName { get; set; }
        public string Region { get; set; }
    }
}
